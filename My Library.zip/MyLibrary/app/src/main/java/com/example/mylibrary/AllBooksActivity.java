package com.example.mylibrary;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class AllBooksActivity extends AppCompatActivity {
    private RecyclerView booksRecView;
    private BookRecViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_books);
        adapter = new BookRecViewAdapter(this);
        booksRecView  = findViewById(R.id.booksRecView);

        booksRecView.setAdapter(adapter);
        booksRecView.setLayoutManager(new LinearLayoutManager(this));

        ArrayList<Book> books = new ArrayList<>();
        books.add(new Book(1, "Die drei ???", "Robert Arthur", 128, "https://cms.kosmos.de/Artikel/978-3-440-50445-1/46181/image-thumb__46181__standardProduct/9783440173015.jpg","Justus, Peter und Bob sind beste Freunde und Detektive! Zusammen haben die drei ??? schon viele knifflige Fälle gelöst.","Justus, Peter und Bob sind beste Freunde und Detektive! Zusammen haben die drei ??? schon viele knifflige Fälle gelöst.\n" +
                "Bereits im ersten Band der Kultreihe riecht es gewaltig nach Abenteuer. Eigentlich haben Justus, Peter und Bob ja gerade Ferien. Doch dann treffen sie auf den schrulligen Kapitän Larsson, der einen kleinen Privatzoo mit exotischen Tieren betreibt. Als plötzlich alle Tiere an rätselhaften Infektionen erkranken und die Besucher ausbleiben, werden die drei ??? Kids neugierig. Schon bald merken sie, dass da jemand ein düsteres Geheimnis hütet..."));
        books.add(new Book(2,
                "Feuer und Blut",
                "George R. R. Martin",
                896,
                "https://m.media-amazon.com/images/I/A1DdaqXIy5L._SL1500_.jpg",
                "Aufstieg und Fall des Hauses Targaryen von Westeros - Als »House of the Dragon« von HBO verfilmt"
                ,"Was für Tolkiens Fans das Silmarillion ist, erscheint nun von George R.R. Martin – die epische Vorgeschichte von »Das Lied von Eis und Feuer« " +
                "/ »Game of Thrones«! Drei Jahrhunderte, bevor die Serie beginnt, eroberte Aegon Targaryen mit seinen Schwestergemahlinnen " +
                "und ihren drei Drachen den Kontinent Westeros. 280 Jahre währte die Herrschaft seiner Nachkommen. " +
                "Sie überstanden Rebellion und Bürgerkrieg – bis Robert Baratheon den irren König Aerys II. vom Eisernen Thron stürzte. " +
                "Dies ist die Geschichte des großen Hauses Targaryen, niedergeschrieben von Erzmaester Gyldayn, transkribiert von George R.R. Martin."));
        adapter.setBooks(books);
    }
}