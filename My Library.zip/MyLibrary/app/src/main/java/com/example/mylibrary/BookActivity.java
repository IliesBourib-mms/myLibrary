package com.example.mylibrary;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class BookActivity extends AppCompatActivity {

    private TextView txtBookNameValue, txtAuthorName, txtPages, txtShortDesc, txtLongDesc;
    private Button btnAddToWantToRead, btnAddAlreadyRead, btnAddToCurrentlyReading, btnAddFavourites;
    private ImageView imgBook;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        initViews();
        //TODO: Get the data from recycler view in here
        Book book = new Book(2,
                "Feuer und Blut",
                "George R. R. Martin",
                896,
                "https://m.media-amazon.com/images/I/A1DdaqXIy5L._SL1500_.jpg",
                "Aufstieg und Fall des Hauses Targaryen von Westeros - Als »House of the Dragon« von HBO verfilmt"
                ,"Was für Tolkiens Fans das Silmarillion ist, erscheint nun von George R.R. Martin – die epische Vorgeschichte von »Das Lied von Eis und Feuer« " +
                "/ »Game of Thrones«! Drei Jahrhunderte, bevor die Serie beginnt, eroberte Aegon Targaryen mit seinen Schwestergemahlinnen " +
                "und ihren drei Drachen den Kontinent Westeros. 280 Jahre währte die Herrschaft seiner Nachkommen. " +
                "Sie überstanden Rebellion und Bürgerkrieg – bis Robert Baratheon den irren König Aerys II. vom Eisernen Thron stürzte. " +
                "Dies ist die Geschichte des großen Hauses Targaryen, niedergeschrieben von Erzmaester Gyldayn, transkribiert von George R.R. Martin.");
        
        setData(book);
    }

    private void setData(Book book) {
        txtBookNameValue.setText(book.getName());
        txtPages.setText(book.getPages());
        txtAuthorName.setText(String.valueOf(book.getPages()));
        txtLongDesc.setText(book.getLongDesc());
        Glide.with(this)
                .asBitmap()
                .load(book.getImageUrl())
                .into(imgBook);
    }

    private void initViews() {
        txtBookNameValue = findViewById(R.id.txtBookNameValue);
        txtAuthorName = findViewById(R.id.txtAuthorNameValue);
        txtPages = findViewById(R.id.txtPagesValue);
        txtShortDesc = findViewById(R.id.txtShortDesc);
        txtLongDesc = findViewById(R.id.txtLongDesc);
        btnAddToWantToRead = findViewById(R.id.btnAddWantToRead);
        btnAddAlreadyRead = findViewById(R.id.btnAddAlreadyReadedBooks);
        btnAddToCurrentlyReading = findViewById(R.id.btnAddCurrentlyReading);
        btnAddFavourites = findViewById(R.id.btnAddFavourites);
        imgBook = findViewById(R.id.imgBook);
    }
}